﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace program5
{
    public partial class frmColesApp : Form
    {
        public frmColesApp()
        {
            InitializeComponent();
        }

        private void reset()
        {
            lblSubTotal.Text = "0.00";
            lblTax.Text = "0.00";
            lblTotal.Text = "0.00";
            lblSavings.Text = "0.00";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmColesApp_Load(object sender, EventArgs e)
        {
            reset();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            lblSubTotal.Text = nudSubtotal.Text;
            double total = double.Parse(nudSubtotal.Text);
            double salePercent = double.Parse(nudSalePercent.Text)/100;
            double extraPercent = double.Parse(nudExtraDiscount.Text)/100;

            total *= (1 - salePercent);
            total *= (1 - extraPercent);

            double savings = double.Parse(lblSubTotal.Text) - total;

            lblTax.Text = (total * 0.06).ToString("N2");
            total += (total * 0.06);

            lblTotal.Text = total.ToString("N2");
            lblSavings.Text = savings.ToString("N2");
        }
    }
}
